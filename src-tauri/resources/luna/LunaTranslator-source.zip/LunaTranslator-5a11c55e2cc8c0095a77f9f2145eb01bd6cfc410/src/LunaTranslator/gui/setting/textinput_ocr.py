from qtsymbols import *
import functools, os
from myutils.config import globalconfig, ocrsetting, ocrerrorfix
from myutils.utils import splitocrtypes, getimagefilefilter, selectdebugfile
from gui.inputdialog import postconfigdialog, autoinitdialog_items, autoinitdialog
from gui.usefulwidget import (
    D_getsimplecombobox,
    D_getspinbox,
    D_getIconButton,
    getIconButton,
    yuitsu_switch,
    D_getsimpleswitch,
    getsimpleswitch,
    D_getdoclink,
    ClickableLabel,
    createfoldgrid,
    TableViewW,
    saveposwindow,
    check_grid_append,
    pixmapviewer,
    LStandardItemModel,
    SuperCombo,
    getsmalllabel,
    manybuttonlayout,
    makesubtab_lazy,
    create_centered_rect,
    makescrollgrid,
    maketabholder,
    makecardrow,
    makescroll,
)
from gui.fluent.expander import ExExpander
from gui.rangeselect import add_overlay_style_rows, set_global_mousetransp
from gui.specialwidget import KeyPressDetector
from traceback import print_exc
import gobject, qtawesome, importlib
from gui.dynalang import LDialog, LAction, LLabel
from myutils.ocrutil import ocr_end, ocr_init, ocr_run
from myutils.wrapper import threader, Singleton
from ocrengines.baseocrclass import OCRResultParsed


def __label1(self):
    threshold1label = QLabel()
    gobject.base.connectsignal(gobject.base.thresholdsett1, threshold1label.setText)
    return threshold1label


def __label2(self):
    threshold2label = QLabel()
    gobject.base.connectsignal(gobject.base.thresholdsett2, threshold2label.setText)
    return threshold2label


@threader
def __directinitend(_, _ok):
    if _ok:
        ocr_init()
    else:
        ocr_end()


@Singleton
class triggereditor(LDialog):
    def showmenu(self, p: QPoint):
        curr = self.hctable.currentIndex()
        r = curr.row()
        if r < 0:
            return
        menu = QMenu(self.hctable)
        remove = LAction("删除", menu)
        menu.addAction(remove)
        action = menu.exec(self.hctable.cursor().pos())

        if action == remove:
            self.hctable.removeselectedrows()

    def __init__(self, parent) -> None:
        super().__init__(parent)
        self.list: "list[dict]" = globalconfig["ocr_trigger_events"]

        self.setWindowTitle("触发事件")
        model = LStandardItemModel()
        model.setHorizontalHeaderLabels(["按键", "事件"])
        self.hcmodel = model
        table = TableViewW()
        table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        table.horizontalHeader().setStretchLastSection(True)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setWordWrap(False)
        table.setModel(model)
        table.getindexdata = self.__getindexwidgetdata
        table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        table.customContextMenuRequested.connect(self.showmenu)
        self.hctable = table
        self.internalrealname = []
        formLayout = QVBoxLayout(self)
        formLayout.addWidget(self.hctable)
        for row, k in enumerate(self.list):  # 2
            self.hcmodel.insertRow(row, [QStandardItem(), QStandardItem()])
            combo = KeyPressDetector(k.get("vkey"))
            self.hctable.setIndexWidget(self.hcmodel.index(row, 0), combo)
            combo = SuperCombo()
            combo.addItems(["按下", "松开"])
            combo.setCurrentIndex(k.get("event", 0))
            self.hctable.setIndexWidget(self.hcmodel.index(row, 1), combo)
        buttons = manybuttonlayout(
            (("添加行", self.click1), ("删除行", self.hctable.removeselectedrows))
        )
        formLayout.addLayout(buttons)
        self.resize(600, self.sizeHint().height())
        self.show()

    def __getindexwidgetdata(self, index: QModelIndex):
        if index.column() == 0:
            return self.hctable.indexWidgetX(index).text()
        else:
            return self.hctable.indexWidgetX(index).currentIndex()

    def closeEvent(self, a0: QCloseEvent) -> None:
        rows = self.hcmodel.rowCount()
        self.list.clear()
        for row in range(rows):
            i0 = self.hctable.getdata(row, 0)
            i1 = self.hctable.getdata(row, 1)
            self.list.append({"vkey": i0, "event": i1})

    def click1(self):
        self.hcmodel.insertRow(0, [QStandardItem(), QStandardItem()])
        combo = KeyPressDetector()
        self.hctable.setIndexWidget(self.hcmodel.index(0, 0), combo)
        combo = SuperCombo()
        combo.addItems(["按下", "松开"])
        self.hctable.setIndexWidget(self.hcmodel.index(0, 1), combo)


def safeloadfunction(p, args, file, func, name):
    try:
        func = getattr(importlib.import_module(file), func)
        func(p, args, name)
    except:
        print_exc()


def checkclickable(name: ClickableLabel):
    name.setClickable(globalconfig.get("useproxy", True))


def renameapi(qlabel: QLabel, apiuid):
    menu = QMenu(qlabel)
    useproxy = LAction("使用代理", menu)
    useproxy.setCheckable(True)

    menu.addAction(useproxy)
    useproxy.setChecked(globalconfig["ocr"][apiuid].get("useproxy", True))
    pos = QCursor.pos()
    action = menu.exec(pos)

    if action == useproxy:
        globalconfig["ocr"][apiuid]["useproxy"] = useproxy.isChecked()


def getrenameablellabel(uid):
    if globalconfig["ocr"][uid].get("type") in ("offline",):
        return LLabel(globalconfig["ocr"][uid]["name"])
    name = ClickableLabel(globalconfig["ocr"][uid]["name"])
    fn = functools.partial(renameapi, name, uid)
    name.clicked.connect(fn)
    name.beforeEnter.connect(functools.partial(checkclickable, name))
    return name


savelenx = 0


def initgridsources(self, names):
    line = []
    i = 0
    grids_source = []
    for name in names:
        _f = "Lunatranslator/ocrengines/{}.py".format(name)
        if os.path.exists(_f) == False:
            continue
        if globalconfig["ocr"][name].get("argstype", None):
            _3 = D_getIconButton(
                callback=functools.partial(
                    safeloadfunction,
                    self,
                    ocrsetting[name]["args"],
                    "ocrengines." + name,
                    globalconfig["ocr"][name].get("argstype", None),
                    globalconfig["ocr"][name]["name"],
                )
            )
        elif name == "selfbuild":
            _3 = D_getIconButton(
                callback=lambda: selectdebugfile("selfbuild_ocr.py"),
                icon="fa.edit",
            )
        elif name in ocrsetting:
            items = autoinitdialog_items(ocrsetting[name])
            _3 = D_getIconButton(
                callback=functools.partial(
                    autoinitdialog,
                    self,
                    ocrsetting[name]["args"],
                    globalconfig["ocr"][name]["name"],
                    800,
                    items,
                    "ocrengines." + name,
                    name,
                )
            )
        else:
            _3 = ""

        line += [
            functools.partial(getrenameablellabel, name),
            D_getsimpleswitch(
                globalconfig["ocr"][name],
                "use",
                name=name,
                parent=self,
                callback=functools.partial(
                    yuitsu_switch,
                    self,
                    globalconfig["ocr"],
                    "ocrswitchs",
                    name,
                    __directinitend,
                ),
                pair="ocrswitchs",
            ),
            _3,
        ]
        if i % 3 == 2:
            grids_source.append(line)
            line = []
        else:
            line += [""]
        i += 1
    if len(line):
        grids_source.append(line)
    check_grid_append(grids_source)

    global savelenx
    if len(grids_source) >= 2:
        savelenx = savelenx if savelenx else len(grids_source[0])
    elif len(grids_source) == 1:
        grids_source[0] += [""] * (savelenx - len(grids_source[0]))

    return grids_source


def _ocrparam_create(self, f):
    exp = self._ocrparamexp
    exp.clearContentWidgets()

    def row(label, *controls):
        r = QWidget()
        lay = QHBoxLayout(r)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(LLabel(label))
        lay.addStretch(1)
        for c in controls:
            if callable(c):
                c = c()
            if c is not None:
                lay.addWidget(c)
        exp.addContentWidget(r)

    if f == "period":
        row(
            "执行周期_(s)",
            D_getspinbox(
                0.1, 100, globalconfig, "ocr_interval", double=True, default=1.5
            ),
        )
    if f == "trigger":
        row(
            "触发事件",
            D_getIconButton(functools.partial(triggereditor, self)),
        )
        row(
            "延迟_(s)",
            D_getspinbox(
                0,
                100,
                globalconfig,
                "ocr_trigger_delay",
                double=True,
                default=0,
            ),
        )
    if f in ["analysis", "trigger"]:
        row(
            "图像稳定性阈值",
            functools.partial(__label1, self),
            D_getspinbox(
                0,
                1,
                globalconfig,
                ("ocr_stable_sim_v2", "ocr_stable_sim2_v2")[f == "trigger"],
                double=True,
                step=0.001,
                default=(0.5, 0.95)[f == "trigger"],
            ),
        )
    if f == "analysis":
        row(
            "图像一致性阈值",
            functools.partial(__label2, self),
            D_getspinbox(
                0,
                1,
                globalconfig,
                "ocr_diff_sim_v2",
                double=True,
                step=0.001,
                default=0.95,
            ),
        )
    row(
        "文本相似度阈值",
        D_getspinbox(0, 100000, globalconfig, "ocr_text_diff", default=3),
    )


def _ocrparam(self, exp):
    """自动化执行方法的参数子项（每行一个卡子项，方法切换时经
    _ocrparam_create 重建）。"""
    self._ocrparamexp = exp
    _ocrparam_create(self, globalconfig.get("ocr_auto_method_v2", "period"))


@Singleton
class showocrimage(saveposwindow):
    def closeEvent(self, e):
        super().closeEvent(e)
        self.deleteLater()

    def openff(self):
        f = QFileDialog.getOpenFileName(filter=getimagefilefilter())
        res = f[0]
        if not res:
            return
        self.ocrfile(res)

    def ocrfile(self, res):
        img = QImage(res)
        if img.isNull():
            return
        self.originimage = img
        self.setimagefunction(img)
        result = ocr_run(img)
        result = result.maybeerror()

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event: QDropEvent):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        if len(files):
            self.ocrfile(files[0])

    def __init__(self, parent):
        self.originimage = None
        super().__init__(
            parent,
            posinit=gobject.tempconfig.get(
                "showocrgeo",
                create_centered_rect(600, 300, gobject.base.settin_ui).getRect(),
            ),
            possave=functools.partial(gobject.tempconfig.__setitem__, "showocrgeo"),
        )
        self.setWindowIcon(qtawesome.icon("fa.picture-o"))
        self.setWindowTitle("查看")
        self.originlabel = pixmapviewer()
        qw = QWidget()
        self.layout1 = QVBoxLayout(qw)
        self.setAcceptDrops(True)
        self.setCentralWidget(qw)
        icon = getIconButton(callback=self.openff, icon="fa.file-image-o")
        button = getIconButton(callback=self.retest, icon="fa.rotate-right")
        button2 = getIconButton(callback=self.retest2, icon="fa.rotate-right")
        hb = QHBoxLayout()
        hb.addWidget(icon)
        hb.addWidget(button)
        hb.addWidget(button2)
        self.dial = QSpinBox(self)
        self.dial.setRange(0, 359)
        self.dial.setWrapping(True)
        self.dial.valueChanged.connect(self.onValueChanged)
        self.dial.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        hb.addWidget(self.dial)
        self.layout1.addLayout(hb)
        self.timecost = QLabel()
        self.timecost.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )
        self.layout1.addWidget(self.timecost)
        self.layout1.addWidget(self.originlabel)
        gobject.base.connectsignal(gobject.base.setimage, self.setimagefunction)
        gobject.base.connectsignal(gobject.base.setresult, self.setocr)
        self.show()

    def onValueChanged(self, value):
        if not self.originimage:
            return
        transform = QTransform()
        transform.rotate(value)
        rotated_image = self.originimage.transformed(transform)
        self.originlabel.showpixmap(QPixmap.fromImage(rotated_image))

    def retest2(self):
        gobject.base.textgetmethod(self.retest(), is_auto_run=False)

    def retest(self):
        if self.originimage is None:
            return
        transform = QTransform()
        transform.rotate(self.dial.value())
        result = ocr_run(self.originimage.transformed(transform))
        return result.maybeerror()

    def setimagefunction(self, originimage):
        self.originimage = originimage
        self.originlabel.showpixmap(QPixmap.fromImage(originimage))

    def setocr(self, result: OCRResultParsed):
        self.timecost.setText("time: {}".format(result.timecost))
        self.originlabel.showboxtext(result.result)


def _expander_header(title, *controls, after_title=None):
    """折叠卡头部行：标题（后可紧跟 after_title 挂件，如 doclink）在左、
    控件靠右（同设置窗口折叠卡头部）。"""
    header = QWidget()
    hlay = QHBoxLayout(header)
    hlay.setContentsMargins(0, 12, 0, 12)
    hlay.setSpacing(8)
    titlelabel = LLabel(title)
    titlefont = titlelabel.font()
    titlefont.setPixelSize(15)
    titlelabel.setFont(titlefont)
    hlay.addWidget(titlelabel)
    if after_title is not None:
        if callable(after_title):
            after_title = after_title()
        if after_title is not None:
            hlay.addWidget(after_title)
    hlay.addStretch(1)
    for c in controls:
        if callable(c):
            c = c()
        if c is not None:
            hlay.addWidget(c)
    return header


def _otherspage(self, l):
    """OCR 其他设置页：每项一张卡（合并临近行/自动化执行方法为折叠卡，
    子项经折叠展开）。"""
    # 滚动内容控件必须用 QSS 类做透明：否则会被 autofill 以 Window 色
    # 盖掉页面卡底色（同 gamemanager/setting 的 ___tabf 注释）
    class _othersscrollcontent(QWidget):
        pass

    content = _othersscrollcontent()
    content.setStyleSheet("_othersscrollcontent{background-color:transparent;}")
    vlay = QVBoxLayout(content)
    vlay.setContentsMargins(16, 16, 16, 12)
    vlay.setSpacing(8)
    vlay.addWidget(
        makecardrow(
            "识别方向",
            D_getsimplecombobox(
                ["横向", "竖向", "自适应"], globalconfig, "verticalocr", default=2
            ),
        )
    )
    merge = ExExpander(content_pad=True)
    merge.setHeaderWidget(
        _expander_header(
            "合并临近行",
            D_getsimpleswitch(globalconfig, "ocrmergelines", default=True),
        )
    )
    distrow = QWidget()
    dlay = QHBoxLayout(distrow)
    dlay.setContentsMargins(0, 0, 0, 0)
    dlay.addWidget(LLabel("距离"))
    dlay.addStretch(1)
    dlay.addWidget(
        D_getspinbox(
            0,
            3,
            globalconfig,
            "ocrmergelines_distance",
            double=True,
            step=0.01,
            default=0.4,
        )()
    )
    dlay.addWidget(getsmalllabel("x")())
    merge.addContentWidget(distrow)
    vlay.addWidget(merge)
    # 原地显示翻译：折叠卡，头部开关，子项 = 与右键菜单样式飞层共用
    # 的样式子项（双向同步）
    inplace = ExExpander(content_pad=True)
    inplace.setHeaderWidget(
        _expander_header("原地显示翻译", _inplace_switch)
    )
    add_overlay_style_rows(inplace)
    vlay.addWidget(inplace)
    vlay.addWidget(makecardrow("鼠标穿透范围框", _mousetransp_switch))
    vlay.addWidget(
        makecardrow(
            "多重区域模式",
            D_getsimpleswitch(
                globalconfig,
                "multiregion",
                callback=lambda _: gobject.base.textsource.leaveone(),
                default=False,
            ),
        )
    )
    vlay.addWidget(
        makecardrow(
            "易错内容修正",
            D_getIconButton(
                callback=functools.partial(
                    postconfigdialog,
                    self,
                    ocrerrorfix["args"]["替换内容"],
                    "易错内容修正",
                    ["原文内容", "替换为"],
                )
            ),
            D_getsimpleswitch(ocrerrorfix, "use"),
        )
    )
    auto = ExExpander(content_pad=True)
    auto.setHeaderWidget(
        _expander_header(
            "自动化执行方法",
            D_getsimplecombobox(
                ["分析图像更新", "周期执行", "鼠标键盘触发+等待稳定"],
                globalconfig,
                "ocr_auto_method_v2",
                internal=["analysis", "period", "trigger"],
                callback=functools.partial(_ocrparam_create, self),
                default="period",
            ),
            after_title=D_getdoclink("ocrparam.html#anchor-auto"),
        )
    )
    _ocrparam(self, auto)
    auto.setExpanded(True)
    vlay.addWidget(auto)
    vlay.addStretch(1)
    scroll = makescroll()
    scroll.setWidget(content)
    l.addWidget(scroll)


def _mousetransp_switch():
    """鼠标穿透范围框开关：全局恒定，与范围框右键菜单互相同步。"""
    btn = getsimpleswitch(
        globalconfig,
        "ocrrangemousetransp",
        default=False,
        callback=lambda v: set_global_mousetransp(v, update_switch=False),
    )
    gobject.base.ocr_mousetransp_sync.connect(btn.setChecked)
    return btn


def _inplace_switch():
    """原地显示翻译开关：与 OCR 选框右键菜单互相同步。"""
    btn = getsimpleswitch(
        globalconfig,
        "ocr_translation_overlay",
        default=False,
        callback=lambda _: getattr(
            gobject.base.textsource, "setstyle", lambda: None
        )(),
    )
    gobject.base.ocr_inplace_switch.connect(btn.setChecked)
    return btn


def internal(self):
    offline, online, other = splitocrtypes(globalconfig["ocr"], other=True)
    outdate = [_ for _ in offline if globalconfig["ocr"][_].get("outdate", False)]
    offline = [_ for _ in offline if _ not in outdate]
    offgrids = initgridsources(self, offline)
    engines = [
        [
            dict(
                title="离线",
                type="grid",
                grid=offgrids,
                widget=D_getdoclink("useapis/ocrapi.html#anchor-offline"),
            )
        ],
        [
            dict(
                title="在线",
                type="grid",
                grid=initgridsources(self, online),
                widget=D_getdoclink("useapis/ocrapi.html#anchor-online"),
            )
        ],
        [
            (
                functools.partial(
                    createfoldgrid,
                    [
                        [
                            dict(
                                type="grid",
                                title="其他",
                                grid=initgridsources(self, other),
                            )
                        ],
                        [
                            dict(
                                type="grid",
                                title="过时的",
                                grid=initgridsources(self, outdate),
                            )
                        ],
                    ],
                    "其他",
                    d=globalconfig["foldstatus"]["ocr"],
                    k="other",
                ),
                -1,
            )
        ],
        [
            D_getIconButton(
                callback=lambda: showocrimage(self), icon="fa.picture-o", tips="查看"
            ),
            "",
        ],
    ]
    tab, dotab = makesubtab_lazy(
        ["OCR引擎", "其他设置"],
        [
            # 顶边距 16，与其他设置页首卡一致
            lambda l: makescrollgrid(engines, l, topmargin=16),
            functools.partial(_otherspage, self),
        ],
        delay=True,
    )
    return tab, dotab


def getocrgrid_table(self, basel: QVBoxLayout):

    self.ocrswitchs = {}

    gridlayoutwidget, do = internal(self)
    basel.addWidget(maketabholder(gridlayoutwidget))
    do()
