# Anki Integration

1. Install Anki, https://apps.ankiweb.net/ go to the homepage to download and install.

2.

![img](https://image.lunatranslator.org/zh/anki/336449710-95f90d9a-cfe6-42c3-a44f-64d88d13833d.png)

3.

![img](https://image.lunatranslator.org/zh/anki/336450025-9bf64445-f62e-4bfe-86f7-da99a7100e92.png)

Enter the number `2055492159` and restart Anki.

---

On the Luna side, after clicking on the word lookup.

![img](https://image.lunatranslator.org/zh/anki/336451202-a2dd54c0-e4ee-4c27-9183-8b4ab05c4819.png)

![img](https://image.lunatranslator.org/zh/anki/336451442-7887d600-8c44-4256-9020-1d85e0f6184a.png)

---

Reference: [asukaminato0721](https://github.com/HIllya51/LunaTranslator/issues/796)