# Cài đặt Tiện ích Trình duyệt Yomitan

1. Đảm bảo công cụ hiển thị là Webview2
  
   Sử dụng tiện ích trình duyệt yêu cầu Webview2. Trừ khi hệ thống không hỗ trợ Webview2, công cụ hiển thị mặc định sẽ là Webview2.

   ![img](https://image.lunatranslator.org/en/extension/1.png)

1. Kích hoạt **Sử dụng Tiện ích Trình duyệt** và thêm tiện ích Yomitan.

    >[!WARNING]
    >Bạn nên thêm phiên bản tiện ích mở rộng dành cho Chrome/Edge. Phiên bản dành cho Firefox không tương thích.

   ![img](https://image.lunatranslator.org/en/extension/2.png)

   ![img](https://image.lunatranslator.org/zh/yomitan2.png)

1. Chờ quá trình khởi tạo hoàn tất, sau đó cấu hình Yomitan.
   
   >[!WARNING]
   >Đôi khi sau khi thêm plugin, nó có thể không được nhận diện. Bạn cần đóng phần mềm và mở lại để nhận diện.

   ![img](https://image.lunatranslator.org/en/yomitan4.png)

1. Kết quả cuối cùng

   > [!TIP]
   > Theo mặc định, cửa sổ chính sẽ tự động điều chỉnh kích thước dựa trên nội dung văn bản và bản dịch, điều này cũng làm thay đổi kích thước cửa sổ Yomitan.
   >
   > Vào **Cài đặt hiển thị** → **Cài đặt giao diện**, bỏ chọn **Tự động điều chỉnh chiều cao**, hoặc đặt một **Chiều cao tối thiểu** đủ lớn để chứa Yomitan.
   >
   > ![img](https://image.lunatranslator.org/en/extension/3.png)


   ![img](https://image.lunatranslator.org/zh/yomitan5.png)

1. Ngoài giao diện chính, cửa sổ văn bản lịch sử cũng có thể sử dụng tiện ích trình duyệt, nhưng mặc định không được bật để tiết kiệm tài nguyên.

   ![img](https://image.lunatranslator.org/zh/yomitan7.png)

   ![img](https://image.lunatranslator.org/zh/yomitan6.png)

   ![img](https://image.lunatranslator.org/zh/yomitan8.png)