.\LunaTranslator.exe
pause